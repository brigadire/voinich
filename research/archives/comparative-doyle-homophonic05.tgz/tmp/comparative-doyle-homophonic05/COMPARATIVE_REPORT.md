# Comparative experiment report

Similarity is not classification, causal explanation, or proof that the nearest corpus has the same document type. No semantic interpretation is computed.

## Experiment inventory and provenance

- `08a7e68001a438b7777e8c388f00da2f9202154c4fb2298536ad460f1fe95ee7`: mode=generic, frozen=false, verification=NOT_RUN, corpus=`4bc3c5b699cb6e433399c668b5cc49478f3c6d045128ca6c3a2bd0ce3a1423e5`, tokens=43713, vocabulary=10285, manifest_sha256=`5ab35733d3da137da602117c665132e74d95f4af06313a2885625a6ef949375a`, transformation=none.
- `3b637a091449c154922b6d2b7d62f2cb41d5ae143c447e1c6bf7e432b9604fdc`: mode=generic, frozen=false, verification=NOT_RUN, corpus=`8a27e48af6f49cb88d37ed4425e06d28d8b17c0652e299d15e677a7f3227ac3d`, tokens=43713, vocabulary=11528, manifest_sha256=`73c0658cb837d0acd363d7a2b5e958ca11cc6b97bb5aabaeb4adfcff7afca499`, transformation=none.
- `b5e74ffd7c57584a2b1d1a0c90c997d401582c2aa6869e58260dc3dd30dca268`: mode=generic, frozen=false, verification=NOT_RUN, corpus=`9b0b4fba404ddbf574649b9f64c515f9f0ce35113e5d6c8401b01c39ec3d77c3`, tokens=43713, vocabulary=8456, manifest_sha256=`c6f9d67a89d06a610f11be0f25db54efdd160b5133771ef497f8ad66abcfa627`, transformation=none.
- `c121267975bd5636147bcd887d938236b41309a3dbfa314cced2a5554fbd998f`: mode=generic, frozen=false, verification=NOT_RUN, corpus=`0b260c8ae9ee7dcfd8c334e174b32ec433d37792ecfa783137b0bd38a956cc80`, tokens=43713, vocabulary=5360, manifest_sha256=`a7dcefb4c3526f21a7304eeb97f703d41199c6a9c539d8c8d42553b01fe60272`, transformation=none.
- `ff7a92749139f45db9fd695cc96708b8a5aa0989a598ae456cba6b558d647844`: mode=generic, frozen=false, verification=NOT_RUN, corpus=`f46f4190af65b85d145ec5bb957c1f56029b567e4bef12ac7baa1797f358d692`, tokens=39380, vocabulary=8244, manifest_sha256=`c131fd882c3ec94290620c1248805d43698f0c4b4694dacd65e889d27aa9c143`, transformation=none.

## Fingerprint families

Features are grouped by their public semantic prefix: lexical/corpus, sequence, relation, higher_order, transition, and vocabulary_growth. Raw metrics and support values are retained separately; raw counts and support-only fields are excluded from distance unless explicitly defined.

## Common core and missingness

- comparison schema: v2
- experiments: 5
- common-core dimensions: 7
- common-core features: `corpus.eligible_token_rate, relation.replication_rate, relation.significant_rate, sequence.replication_rate, sequence.significant_rate, transition.incoming_profile_rate, transition.outgoing_profile_rate`
- normalization scope: current comparison cohort; standardized distances are exploratory for small N.

Statuses distinguish VALUE, COMPLETED_EMPTY, NOT_APPLICABLE, NOT_COMPUTED, MISSING_ARTIFACT, and FAILED/INVALID.

## Vocabulary Growth Comparison

- `08a7e68001a438b7777e8c388f00da2f9202154c4fb2298536ad460f1fe95ee7`: N=43713, V=10285, Heaps beta=0.77391073, R²=0.99780883, hapax fraction=0.62440447.
- `3b637a091449c154922b6d2b7d62f2cb41d5ae143c447e1c6bf7e432b9604fdc`: N=43713, V=11528, Heaps beta=0.78915383, R²=0.99765996, hapax fraction=0.64078765.
- `b5e74ffd7c57584a2b1d1a0c90c997d401582c2aa6869e58260dc3dd30dca268`: N=43713, V=8456, Heaps beta=0.75308632, R²=0.99709725, hapax fraction=0.58609272.
- `c121267975bd5636147bcd887d938236b41309a3dbfa314cced2a5554fbd998f`: N=43713, V=5360, Heaps beta=, R²=, hapax fraction=.
- `ff7a92749139f45db9fd695cc96708b8a5aa0989a598ae456cba6b558d647844`: N=39380, V=8244, Heaps beta=0.76017313, R²=0.99947693, hapax fraction=0.69007763.

Common-N and trajectory rows are in `pairwise_comparisons.tsv`; no corpus is physically truncated.

## Distances

`pairwise_available_*` distances use only valid dimensions for each pair and report coverage. `*_common_core` distances use the same dimensions for every experiment. `family_distances.tsv` reports family-level common-core distances. All features have equal weight; no weights were fitted to these corpora.

## Support and limitations

Support denominators remain in `raw_metrics.tsv` and `metric_support.tsv` where available. Missing Task49 is not zero. Categorical metadata labels are excluded as incompatible semantics. Transformation provenance is audit metadata only and never a feature.

Similarity != classification. Similarity != causal explanation. Nearest corpus != same document type.
