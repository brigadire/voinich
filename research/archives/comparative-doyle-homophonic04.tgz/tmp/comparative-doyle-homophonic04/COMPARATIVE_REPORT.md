# Comparative experiment report

Similarity is not classification, causal explanation, or proof that the nearest corpus has the same document type. No semantic interpretation is computed.

## Experiment inventory and provenance

- `3d89f39493ca098ad20771f2d26cf4d222c5fd9fc0cc3cb3d13ddf52424c4942`: mode=generic, frozen=false, verification=NOT_RUN, corpus=`165319e63f30ae712e0cb47ffc414e333b7dd2f96ab82beedb4c70a2458b30a8`, tokens=43713, vocabulary=9288, manifest_sha256=`9bf8ab90933dcc915bfef1ba82381a82f01ceadbe8d630792c24d2daededb6d8`, transformation=none.
- `3ea8c9892aac16dbcd8ecfe12c2788f1cbea9fb616d2ce1fb72080817455d7ee`: mode=generic, frozen=false, verification=NOT_RUN, corpus=`d3b3b297e1bf7f7cdd59ffbc2fd38c440eeac461b8db59bbcdd373f211d05057`, tokens=43713, vocabulary=11776, manifest_sha256=`2b5cf7f76c9ccb0ee1b53b228fbb560c0dec0219b46859fe2cd7759ccc9b51cc`, transformation=none.
- `700de2314a9ec2906c0ab4706f6e7188dd0490acdd316963ad98f484fa4122d5`: mode=generic, frozen=false, verification=NOT_RUN, corpus=`cdf533ee521a4e8ebb2dc64c3b862c33fc35de8452456a3e2daf58e5232a383c`, tokens=43713, vocabulary=10671, manifest_sha256=`9ccea0575fc853a99d90cfa4483a03cd3ac53a4c479ffadc5d428032628ae77d`, transformation=none.
- `c121267975bd5636147bcd887d938236b41309a3dbfa314cced2a5554fbd998f`: mode=generic, frozen=false, verification=NOT_RUN, corpus=`0b260c8ae9ee7dcfd8c334e174b32ec433d37792ecfa783137b0bd38a956cc80`, tokens=43713, vocabulary=5360, manifest_sha256=`a7dcefb4c3526f21a7304eeb97f703d41199c6a9c539d8c8d42553b01fe60272`, transformation=none.
- `ff7a92749139f45db9fd695cc96708b8a5aa0989a598ae456cba6b558d647844`: mode=generic, frozen=false, verification=NOT_RUN, corpus=`f46f4190af65b85d145ec5bb957c1f56029b567e4bef12ac7baa1797f358d692`, tokens=39380, vocabulary=8244, manifest_sha256=`c131fd882c3ec94290620c1248805d43698f0c4b4694dacd65e889d27aa9c143`, transformation=none.

## Fingerprint families

Features are grouped by their public semantic prefix: lexical/corpus, sequence, relation, higher_order, transition, and vocabulary_growth. Raw metrics and support values are retained separately; raw counts and support-only fields are excluded from distance unless explicitly defined.

## Common core and missingness

- comparison schema: v2
- experiments: 5
- common-core dimensions: 7
- common-core features: `corpus.eligible_token_rate, relation.replication_rate, relation.significant_rate, sequence.replication_rate, sequence.significant_rate, transition.incoming_profile_rate, transition.outgoing_profile_rate`
- normalization scope: current comparison cohort; standardized distances are exploratory for small N.

Statuses distinguish VALUE, COMPLETED_EMPTY, NOT_APPLICABLE, NOT_COMPUTED, MISSING_ARTIFACT, and FAILED/INVALID.

## Vocabulary Growth Comparison

- `3d89f39493ca098ad20771f2d26cf4d222c5fd9fc0cc3cb3d13ddf52424c4942`: N=43713, V=9288, Heaps beta=0.76360176, R²=0.99761638, hapax fraction=0.62672265.
- `3ea8c9892aac16dbcd8ecfe12c2788f1cbea9fb616d2ce1fb72080817455d7ee`: N=43713, V=11776, Heaps beta=0.79073488, R²=0.99810096, hapax fraction=0.66397758.
- `700de2314a9ec2906c0ab4706f6e7188dd0490acdd316963ad98f484fa4122d5`: N=43713, V=10671, Heaps beta=0.78001006, R²=0.99770944, hapax fraction=0.6472683.
- `c121267975bd5636147bcd887d938236b41309a3dbfa314cced2a5554fbd998f`: N=43713, V=5360, Heaps beta=, R²=, hapax fraction=.
- `ff7a92749139f45db9fd695cc96708b8a5aa0989a598ae456cba6b558d647844`: N=39380, V=8244, Heaps beta=0.76017313, R²=0.99947693, hapax fraction=0.69007763.

Common-N and trajectory rows are in `pairwise_comparisons.tsv`; no corpus is physically truncated.

## Distances

`pairwise_available_*` distances use only valid dimensions for each pair and report coverage. `*_common_core` distances use the same dimensions for every experiment. `family_distances.tsv` reports family-level common-core distances. All features have equal weight; no weights were fitted to these corpora.

## Support and limitations

Support denominators remain in `raw_metrics.tsv` and `metric_support.tsv` where available. Missing Task49 is not zero. Categorical metadata labels are excluded as incompatible semantics. Transformation provenance is audit metadata only and never a feature.

Similarity != classification. Similarity != causal explanation. Nearest corpus != same document type.
