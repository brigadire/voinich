# Comparative experiment report

Similarity is not classification, causal explanation, or proof that the nearest corpus has the same document type. No semantic interpretation is computed.

## Experiment inventory and provenance

- `57723024556a00e0807558c42efab4744ad94ea1b04c7512ee86efd2f0a0b1b2`: mode=generic, frozen=false, verification=NOT_RUN, corpus=`f46f4190af65b85d145ec5bb957c1f56029b567e4bef12ac7baa1797f358d692`, tokens=39380, vocabulary=8244, manifest_sha256=`98e249e6a4373bedffc3d6808fa7813d581ef73d91ca9d839f0645c66e08e38e`, transformation=none.
- `95487ab40c48364262f645ac1cb104092cc4a91d99dc22fb553010a8902c3378`: mode=generic, frozen=false, verification=NOT_RUN, corpus=`9551cc64ae47df0569fe03fdb9ce29253cc293fcab984374448858981fb53217`, tokens=39380, vocabulary=8244, manifest_sha256=`a824177e05fbfae45198b5dc3aa9454042610bdafb6a69d1f3796d5509385ada`, transformation=orientation:GLYPH_REVERSE.
- `b435b6eb137219f08f8c6171f49e702e1905b4124600d73840f94a9231daf0a8`: mode=generic, frozen=false, verification=NOT_RUN, corpus=`4126a0f8dfaff55648dfb7e53a8430758bb4fd6908017692f46bf43e09fe61cf`, tokens=39380, vocabulary=8244, manifest_sha256=`afdc3c40260dfa89d7adcf8160f0bdc6f2c6486f182c097ea1f674864ed26913`, transformation=orientation:FULL_REVERSE.
- `d38cde84b31eca5aae20a4c1c0578a8a51a4cf0cbe1ae41f2f1c59f703c85104`: mode=generic, frozen=false, verification=NOT_RUN, corpus=`ae3a9f932e0803f0e3cb26e51e52c11ce10bb60ee42defbc9b3553c0c70b68d0`, tokens=39380, vocabulary=8244, manifest_sha256=`f73263490b3464866a19ffd42b882b989ce53db18c568719aec5054a61bf4d4c`, transformation=orientation:TOKEN_REVERSE.

## Fingerprint families

Features are grouped by their public semantic prefix: lexical/corpus, sequence, relation, higher_order, transition, and vocabulary_growth. Raw metrics and support values are retained separately; raw counts and support-only fields are excluded from distance unless explicitly defined.

## Common core and missingness

- comparison schema: v2
- experiments: 4
- common-core dimensions: 27
- common-core features: `corpus.eligible_token_rate, higher_order.replication_rate, relation.replication_rate, relation.significant_rate, sequence.replication_rate, sequence.significant_rate, transition.incoming_profile_rate, transition.outgoing_profile_rate, vocabulary_growth.V_1000_per_token, vocabulary_growth.V_16000_per_token, vocabulary_growth.V_2000_per_token, vocabulary_growth.V_32000_per_token, vocabulary_growth.V_4000_per_token, vocabulary_growth.V_8000_per_token, vocabulary_growth.final_hapax_fraction_of_tokens, vocabulary_growth.final_hapax_fraction_of_types, vocabulary_growth.final_new_type_rate, vocabulary_growth.heaps_K, vocabulary_growth.heaps_R2, vocabulary_growth.heaps_beta, vocabulary_growth.order_effect_final, vocabulary_growth.order_effect_max, vocabulary_growth.order_effect_mean, vocabulary_growth.segment_beta_mean, vocabulary_growth.segment_beta_sd, vocabulary_growth.segment_new_type_rate_sd, vocabulary_growth.singleton_to_doubleton_ratio`
- normalization scope: current comparison cohort; standardized distances are exploratory for small N.

Statuses distinguish VALUE, COMPLETED_EMPTY, NOT_APPLICABLE, NOT_COMPUTED, MISSING_ARTIFACT, and FAILED/INVALID.

## Vocabulary Growth Comparison

- `57723024556a00e0807558c42efab4744ad94ea1b04c7512ee86efd2f0a0b1b2`: N=39380, V=8244, Heaps beta=0.76017313, R²=0.99947693, hapax fraction=0.69007763.
- `95487ab40c48364262f645ac1cb104092cc4a91d99dc22fb553010a8902c3378`: N=39380, V=8244, Heaps beta=0.76017313, R²=0.99947693, hapax fraction=0.69007763.
- `b435b6eb137219f08f8c6171f49e702e1905b4124600d73840f94a9231daf0a8`: N=39380, V=8244, Heaps beta=0.75976063, R²=0.99953552, hapax fraction=0.69007763.
- `d38cde84b31eca5aae20a4c1c0578a8a51a4cf0cbe1ae41f2f1c59f703c85104`: N=39380, V=8244, Heaps beta=0.75976063, R²=0.99953552, hapax fraction=0.69007763.

Common-N and trajectory rows are in `pairwise_comparisons.tsv`; no corpus is physically truncated.

## Distances

`pairwise_available_*` distances use only valid dimensions for each pair and report coverage. `*_common_core` distances use the same dimensions for every experiment. `family_distances.tsv` reports family-level common-core distances. All features have equal weight; no weights were fitted to these corpora.

## Support and limitations

Support denominators remain in `raw_metrics.tsv` and `metric_support.tsv` where available. Missing Task49 is not zero. Categorical metadata labels are excluded as incompatible semantics. Transformation provenance is audit metadata only and never a feature.

Similarity != classification. Similarity != causal explanation. Nearest corpus != same document type.
