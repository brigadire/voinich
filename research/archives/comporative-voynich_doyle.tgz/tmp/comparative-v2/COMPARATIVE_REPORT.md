# Comparative experiment report

Similarity is not classification, causal explanation, or proof that the nearest corpus has the same document type. No semantic interpretation is computed.

## Experiment inventory and provenance

- `387856caaafe22bcfcd4735aed58b01f26d782ea5f9bba9b2c571220c8c33bc9`: mode=generic, frozen=false, verification=NOT_RUN, corpus=`d0aeb9696c8524fe29e6cccf27367ce3c117cdc96b76d0493850828b1931ee1d`, tokens=43713, vocabulary=7286, manifest_sha256=`9d457e4d3a551fcd7d95639609c19dd1f7be61ea9eff7843731ef4853aa9ecf0`, transformation=none.
- `b958a06f6b6404974ea32e54c3ba2b295fc5f57ba87e90caab8fd5dd25313b75`: mode=legacy_ivtff, frozen=true, verification=PASS, corpus=`360d99583145ec549b80edfafdc3f93534f3a11b85a0d52997ba8425e92b87c2`, tokens=39026, vocabulary=8363, manifest_sha256=`23f35dba0201932b8f1af84d0fbd44a5ed7a71c5685a4c5722a31382a7c30733`, transformation=none.
- `c121267975bd5636147bcd887d938236b41309a3dbfa314cced2a5554fbd998f`: mode=generic, frozen=false, verification=NOT_RUN, corpus=`0b260c8ae9ee7dcfd8c334e174b32ec433d37792ecfa783137b0bd38a956cc80`, tokens=43713, vocabulary=5360, manifest_sha256=`a7dcefb4c3526f21a7304eeb97f703d41199c6a9c539d8c8d42553b01fe60272`, transformation=none.

## Fingerprint families

Features are grouped by their public semantic prefix: lexical/corpus, sequence, relation, higher_order, transition, and vocabulary_growth. Raw metrics and support values are retained separately; raw counts and support-only fields are excluded from distance unless explicitly defined.

## Common core and missingness

- comparison schema: v2
- experiments: 3
- common-core dimensions: 9
- common-core features: `corpus.eligible_token_rate, relation.replication_rate, relation.significant_rate, sequence.replication_rate, sequence.significant_rate, transition.backbone_retention, transition.incoming_profile_rate, transition.outgoing_profile_rate, transition.preferred_backbone_retention`
- normalization scope: current comparison cohort; standardized distances are exploratory for small N.

Statuses distinguish VALUE, COMPLETED_EMPTY, NOT_APPLICABLE, NOT_COMPUTED, MISSING_ARTIFACT, and FAILED/INVALID.

## Vocabulary Growth Comparison

Task49 vocabulary-growth artifacts are MISSING_ARTIFACT for enough experiments to form a trajectory comparison. Legacy experiments remain valid.

## Distances

`pairwise_available_*` distances use only valid dimensions for each pair and report coverage. `*_common_core` distances use the same dimensions for every experiment. `family_distances.tsv` reports family-level common-core distances. All features have equal weight; no weights were fitted to these corpora.

## Support and limitations

Support denominators remain in `raw_metrics.tsv` and `metric_support.tsv` where available. Missing Task49 is not zero. Categorical metadata labels are excluded as incompatible semantics. Transformation provenance is audit metadata only and never a feature.

Similarity != classification. Similarity != causal explanation. Nearest corpus != same document type.
