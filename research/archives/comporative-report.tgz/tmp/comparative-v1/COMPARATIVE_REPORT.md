# Comparative experiment report

This report is descriptive structural comparison only; no document-class or semantic conclusion is computed.

## Experiment inventory

| experiment | input mode | corpus SHA256 | tokens | vocabulary |
|---|---|---|---:|---:|
| 2d1c5a257dca6df28b05b6003851c6308385bd5b041ecbbe06234b1708b76adb | generic | `f9a751690d4f14edd21481867e21ddbd0cc86ebed4f3214782f1d5064e57e219` | 112162 | 7169 |
| 9470836ccd42a18dfbb73294e9327ae33145666407b8fb48b268a2160bbcc132 | generic | `95bdc2940f56a69e28ac912245d40a601ae329fc42aeec489a3557fc7416c398` | 33077 | 4975 |
| b958a06f6b6404974ea32e54c3ba2b295fc5f57ba87e90caab8fd5dd25313b75 | unknown | `360d99583145ec549b80edfafdc3f93534f3a11b85a0d52997ba8425e92b87c2` | 39026 | 8363 |
| c121267975bd5636147bcd887d938236b41309a3dbfa314cced2a5554fbd998f | generic | `0b260c8ae9ee7dcfd8c334e174b32ec433d37792ecfa783137b0bd38a956cc80` | 43713 | 5360 |

## Applicability and missingness

- `2d1c5a257dca6df28b05b6003851c6308385bd5b041ecbbe06234b1708b76adb`: applicable stages=begin-end-analyze, dict-analyze, dict-gen, distance-context-analyze, global-regime-analyze, higher-order-sequence-validate, local-regime-analyze, normalization-compare, positional-continuation-validate, property-trajectory-analyze, replicated-local-structure-audit, sequence-analyze, soft-structural-space, structural-analyze, structural-graphemic, structural-normalize, structural-pair-decompose, structural-profile-stability, structural-projection-analyze, structural-reliability, structural-validate, token-relation-validate, transition-network-validate; unavailable stages=cluster-metadata-global, conditional-regime-analyze, metadata-validate, residual-diagnostic-analyze.
- `9470836ccd42a18dfbb73294e9327ae33145666407b8fb48b268a2160bbcc132`: applicable stages=begin-end-analyze, dict-analyze, dict-gen, distance-context-analyze, global-regime-analyze, higher-order-sequence-validate, local-regime-analyze, normalization-compare, positional-continuation-validate, property-trajectory-analyze, replicated-local-structure-audit, sequence-analyze, soft-structural-space, structural-analyze, structural-graphemic, structural-normalize, structural-pair-decompose, structural-profile-stability, structural-projection-analyze, structural-reliability, structural-validate, token-relation-validate, transition-network-validate; unavailable stages=cluster-metadata-global, conditional-regime-analyze, metadata-validate, residual-diagnostic-analyze.
- `b958a06f6b6404974ea32e54c3ba2b295fc5f57ba87e90caab8fd5dd25313b75`: applicable stages=begin-end-analyze, cluster-metadata-global, conditional-regime-analyze, dict-analyze, dict-gen, distance-context-analyze, global-regime-analyze, higher-order-sequence-validate, local-regime-analyze, metadata-validate, normalization-compare, positional-continuation-validate, property-trajectory-analyze, replicated-local-structure-audit, residual-diagnostic-analyze, sequence-analyze, soft-structural-space, structural-analyze, structural-graphemic, structural-normalize, structural-pair-decompose, structural-profile-stability, structural-projection-analyze, structural-reliability, structural-validate, token-relation-validate, transition-network-validate; unavailable stages=.
- `c121267975bd5636147bcd887d938236b41309a3dbfa314cced2a5554fbd998f`: applicable stages=begin-end-analyze, dict-analyze, dict-gen, distance-context-analyze, global-regime-analyze, higher-order-sequence-validate, local-regime-analyze, normalization-compare, positional-continuation-validate, property-trajectory-analyze, replicated-local-structure-audit, sequence-analyze, soft-structural-space, structural-analyze, structural-graphemic, structural-normalize, structural-pair-decompose, structural-profile-stability, structural-projection-analyze, structural-reliability, structural-validate, token-relation-validate, transition-network-validate; unavailable stages=cluster-metadata-global, conditional-regime-analyze, metadata-validate, residual-diagnostic-analyze.

The machine-readable tables retain explicit status values. Missing artifacts remain missing (never numeric zero); pairwise distances use only dimensions present in both experiments and report used/missing counts.

## Raw metrics and normalized structural fingerprint

See `raw_metrics.tsv`, `normalized_metrics.tsv`, and `structural_fingerprint.yaml`. The schema and formula registry are fixed at version 1.

## Distances and pairwise comparisons

See `pairwise_distances.tsv` and `pairwise_comparisons.tsv`. With N=4, any distance or comparison is exploratory/illustrative and is not a class assignment.

## PCA and clustering

Omitted for this small sample; no attempt is made to force a projection or cluster solution.

## Methodological limitations

Raw counts depend on corpus size and are retained for audit. Normalized rates use the formulas documented in `experiment-compare/METRIC_COMPATIBILITY.md`. Categorical labels from Voynich-specific metadata and generic GROUP labels are not compared. No semantic interpretation, classifier, or post-hoc feature selection is performed.
